__author__ = 'ravi'
from sys import path
path.insert(0, '/home/ravi/Training/Python-IBM-Hyderabad/day1/lib')

from psutils import ls, name

ls()

pypi.python.org
