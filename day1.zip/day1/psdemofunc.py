__author__ = 'ravi'

def power(x, n=0):
    return x ** n

print power(2, 3)
print power(2)




