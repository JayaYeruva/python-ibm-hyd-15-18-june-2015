__author__ = 'ravi'
from sys import argv


for line in open(argv[1]):
        print line.rstrip()



